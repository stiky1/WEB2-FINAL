<?php
    $lang = array(
        "welcome" => "Ahoj, pozemašťan",
        "lang" => "Jazyky",
        "home" => "Domov",
        "pendulum" => "Inverzné kyvadlo",
        "ball" => "Gulička na tyči",
        "car" => "Tlmič automobilu",
        "airplane" => "Náklon lietadla",

    );