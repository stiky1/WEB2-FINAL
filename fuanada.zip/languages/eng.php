<?php
$lang = array(
    "welcome" => "Welcome, everyone ",
    "lang" => "Languages",
    "home" => "Home",
    "pendulum" => "Inverted pendulum",
    "ball" => "Beam and ball",
    "car" => "Suspension car system",
    "airplane" => "Aircraft pitch control",

);